// routes/market.js
const express = require('express');
const router = express.Router();
const store = require('../data/store');

// GET /api/market — all prices
router.get('/', (req, res) => {
  const { category } = req.query;
  let data = [...store.marketPrices];
  if (category) data = data.filter(p => p.category === category);
  res.json({ success: true, count: data.length, data });
});

// GET /api/market/trending — top movers
router.get('/trending', (req, res) => {
  const sorted = [...store.marketPrices].sort((a, b) => Math.abs(b.change) - Math.abs(a.change));
  res.json({ success: true, data: sorted.slice(0, 5) });
});

// GET /api/market/:id
router.get('/:id', (req, res) => {
  const item = store.marketPrices.find(p => p.id === parseInt(req.params.id));
  if (!item) return res.status(404).json({ success: false, message: 'Price not found' });
  // Generate mock 7-day history
  const history = Array.from({ length: 7 }, (_, i) => ({
    date: new Date(Date.now() - (6 - i) * 86400000).toISOString().split('T')[0],
    price: Math.round(item.price * (0.88 + Math.random() * 0.18)),
  }));
  history[6].price = item.price; // today is accurate
  res.json({ success: true, data: { ...item, history } });
});

// PUT /api/market/:id — update price
router.put('/:id', (req, res) => {
  const idx = store.marketPrices.findIndex(p => p.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ success: false, message: 'Price not found' });
  store.marketPrices[idx] = { ...store.marketPrices[idx], ...req.body, id: store.marketPrices[idx].id };
  res.json({ success: true, data: store.marketPrices[idx] });
});

module.exports = router;
