// routes/tasks.js
const express = require('express');
const router = express.Router();
const store = require('../data/store');
let taskIdCounter = 6;

// GET /api/tasks
router.get('/', (req, res) => {
  const { done, priority } = req.query;
  let data = [...store.tasks];
  if (done === 'false') data = data.filter(t => !t.done);
  if (done === 'true')  data = data.filter(t => t.done);
  if (priority) data = data.filter(t => t.priority === priority);
  data.sort((a, b) => new Date(a.date) - new Date(b.date));
  res.json({ success: true, count: data.length, data });
});

// POST /api/tasks
router.post('/', (req, res) => {
  const { title, description, date, priority } = req.body;
  if (!title || !date) return res.status(400).json({ success: false, message: 'title and date are required' });
  const task = { id: taskIdCounter++, title, description: description || '', date, priority: priority || 'medium', done: false };
  store.tasks.push(task);
  res.status(201).json({ success: true, data: task });
});

// PUT /api/tasks/:id
router.put('/:id', (req, res) => {
  const idx = store.tasks.findIndex(t => t.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ success: false, message: 'Task not found' });
  store.tasks[idx] = { ...store.tasks[idx], ...req.body, id: store.tasks[idx].id };
  res.json({ success: true, data: store.tasks[idx] });
});

// DELETE /api/tasks/:id
router.delete('/:id', (req, res) => {
  const idx = store.tasks.findIndex(t => t.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ success: false, message: 'Task not found' });
  store.tasks.splice(idx, 1);
  res.json({ success: true, message: 'Task deleted' });
});

module.exports = router;
