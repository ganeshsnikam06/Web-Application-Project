// routes/soil.js
const express = require('express');
const router = express.Router();
const store = require('../data/store');

// GET /api/soil — full soil report
router.get('/', (req, res) => {
  const soil = store.soilData;
  // Compute AI-style status labels
  const status = {
    ph:           soil.ph >= 6.0 && soil.ph <= 7.5 ? 'optimal' : soil.ph < 6.0 ? 'acidic' : 'alkaline',
    moisture:     soil.moisture >= 50 ? 'good' : soil.moisture >= 30 ? 'low' : 'critical',
    nitrogen:     soil.nitrogen >= 60 ? 'adequate' : 'deficient',
    phosphorus:   soil.phosphorus >= 50 ? 'adequate' : 'deficient',
    potassium:    soil.potassium >= 80 ? 'high' : soil.potassium >= 50 ? 'adequate' : 'deficient',
    organicMatter:soil.organicMatter >= 3.0 ? 'good' : 'low',
  };
  res.json({ success: true, data: { ...soil, status } });
});

// PUT /api/soil — update sensor readings
router.put('/', (req, res) => {
  Object.assign(store.soilData, req.body, { lastUpdated: new Date().toISOString() });
  res.json({ success: true, data: store.soilData });
});

// GET /api/soil/recommendations — AI-style static recommendations
router.get('/recommendations', (req, res) => {
  const soil = store.soilData;
  const recs = [];
  if (soil.ph >= 6.0 && soil.ph <= 7.5) recs.push({ type: 'good', message: `pH is optimal at ${soil.ph} — excellent for tomatoes, onions and most crops.` });
  else recs.push({ type: 'warning', message: `pH ${soil.ph} is outside the optimal range (6.0–7.5). Consider lime (to raise) or sulphur (to lower).` });
  if (soil.phosphorus < 50) recs.push({ type: 'warning', message: `Low Phosphorus (${soil.phosphorus} mg/kg). Apply DAP at 50 kg/acre before next watering cycle.` });
  if (soil.potassium > 85) recs.push({ type: 'info', message: `High Potassium (${soil.potassium} mg/kg) — good for fruit quality. Reduce potassic fertiliser this month.` });
  if (soil.moisture < 50) recs.push({ type: 'alert', message: `Soil moisture trending low (${soil.moisture}%). Schedule drip irrigation tomorrow 6–8 AM.` });
  if (soil.nitrogen < 60) recs.push({ type: 'warning', message: `Nitrogen deficiency detected. Apply Urea at 25 kg/acre or use green manure.` });
  res.json({ success: true, data: recs });
});

module.exports = router;
