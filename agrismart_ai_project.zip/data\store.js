// data/store.js — In-memory data store (replace with a real DB like MongoDB/PostgreSQL in production)

const crops = [
  { id: 1, name: "Tomato", emoji: "🍅", field: "Field A1", acres: 2, stage: 70, health: "Healthy", sownDate: "2026-01-15", harvestDate: "2026-03-30", daysToHarvest: 3, irrigated: true, notes: "" },
  { id: 2, name: "Onion",  emoji: "🧅", field: "Field B3", acres: 3, stage: 45, health: "Needs Water", sownDate: "2025-12-10", harvestDate: "2026-04-20", daysToHarvest: 24, irrigated: false, notes: "" },
  { id: 3, name: "Wheat",  emoji: "🌾", field: "Field C1", acres: 5, stage: 30, health: "Pest Alert",  sownDate: "2025-11-25", harvestDate: "2026-05-15", daysToHarvest: 49, irrigated: true, notes: "Aphid signs" },
  { id: 4, name: "Maize",  emoji: "🌽", field: "Field D2", acres: 2.5, stage: 85, health: "Excellent", sownDate: "2026-01-05", harvestDate: "2026-03-20", daysToHarvest: -7, irrigated: true, notes: "" },
  { id: 5, name: "Soybean","emoji": "🫘", field: "Field E1", acres: 4, stage: 55, health: "Healthy",   sownDate: "2025-12-20", harvestDate: "2026-04-30", daysToHarvest: 34, irrigated: true, notes: "" },
  { id: 6, name: "Chilli", emoji: "🌶️", field: "Field F2", acres: 1.5, stage: 62, health: "Healthy",  sownDate: "2026-01-10", harvestDate: "2026-04-15", daysToHarvest: 19, irrigated: false, notes: "" },
];
let cropIdCounter = 7;

const soilData = {
  ph: 6.8,
  moisture: 64,
  temperature: 24,
  conductivity: 1.2,
  nitrogen: 78,
  phosphorus: 42,
  potassium: 91,
  organicMatter: 3.4,
  calcium: 1840,
  magnesium: 320,
  lastUpdated: new Date().toISOString(),
};

const marketPrices = [
  { id: 1, name: "Tomato",      emoji: "🍅", category: "vegetable", price: 2840, unit: "quintal", change: 18.2,  direction: "up" },
  { id: 2, name: "Onion",       emoji: "🧅", category: "vegetable", price: 1620, unit: "quintal", change: 4.5,   direction: "up" },
  { id: 3, name: "Potato",      emoji: "🥔", category: "vegetable", price: 1180, unit: "quintal", change: -2.1,  direction: "down" },
  { id: 4, name: "Green Chilli","emoji": "🌶️",category: "vegetable", price: 4200, unit: "quintal", change: 9.8,   direction: "up" },
  { id: 5, name: "Carrot",      emoji: "🥕", category: "vegetable", price: 2050, unit: "quintal", change: -1.3,  direction: "down" },
  { id: 6, name: "Wheat",       emoji: "🌾", category: "grain",     price: 2275, unit: "quintal", change: 1.2,   direction: "up" },
  { id: 7, name: "Maize",       emoji: "🌽", category: "grain",     price: 1950, unit: "quintal", change: 3.4,   direction: "up" },
  { id: 8, name: "Soybean",     emoji: "🫘", category: "grain",     price: 4650, unit: "quintal", change: -0.8,  direction: "down" },
  { id: 9, name: "Chickpea",    emoji: "🟡", category: "pulse",     price: 5420, unit: "quintal", change: 5.7,   direction: "up" },
  { id: 10, name: "Moong Dal",  emoji: "🌿", category: "pulse",     price: 7800, unit: "quintal", change: 2.3,   direction: "up" },
];

const alerts = [
  { id: 1, type: "pest",    icon: "⚠️", title: "Aphid Infestation Risk", message: "Possible aphid infestation detected on Wheat Field C1. Consider inspection and neem oil spray.", time: "2 hours ago", source: "AI Detection", read: false },
  { id: 2, type: "water",   icon: "💧", title: "Irrigation Needed",      message: "Irrigation needed in Onion Patch B3 — soil moisture dropped below 40%.", time: "5 hours ago", source: "Soil Sensor", read: false },
  { id: 3, type: "market",  icon: "📈", title: "Tomato Price Surge",     message: "Tomato prices surged 18% in Nashik APMC — good time to sell!", time: "Today 9:00 AM", source: "Market Data", read: false },
  { id: 4, type: "weather", icon: "🌧️", title: "Rain Forecast Wed-Thu",  message: "Rain expected Wednesday-Thursday. Postpone fertiliser application until after rain clears.", time: "Today 8:00 AM", source: "Weather AI", read: true },
];

const tasks = [
  { id: 1, title: "Irrigate Onion Field B3",     description: "Drip irrigation scheduled for 6–8 AM", date: "2026-03-28", priority: "high",   done: false },
  { id: 2, title: "Harvest Maize Field D2",       description: "Estimated 85% ready. Check moisture content before harvesting.", date: "2026-03-30", priority: "high",   done: false },
  { id: 3, title: "Apply DAP Fertiliser",         description: "Phosphorus low in Field C1. Apply 50 kg/acre.", date: "2026-04-02", priority: "medium", done: false },
  { id: 4, title: "Pest Inspection – Wheat",      description: "Spray Neem oil solution on aphid-affected areas.", date: "2026-04-05", priority: "high",   done: false },
  { id: 5, title: "Soil Sample – Field E1",       description: "Send soil sample to lab for NPK analysis.", date: "2026-04-08", priority: "low",    done: false },
];

module.exports = { crops, cropIdCounter, soilData, marketPrices, alerts, tasks };
