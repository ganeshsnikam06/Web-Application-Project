// routes/weather.js
const express = require('express');
const router = express.Router();
const fetch = require('node-fetch');

// Mock fallback weather (Nashik)
function getMockWeather() {
  return {
    city: process.env.FARM_CITY || 'Nashik',
    country: 'IN',
    temp: 29,
    feelsLike: 31,
    humidity: 68,
    windSpeed: 12,
    windDir: 'NW',
    pressure: 1012,
    visibility: 14,
    uvIndex: 7,
    rainChance: 24,
    description: 'Partly Cloudy',
    icon: '🌤️',
    forecast: [
      { day: 'Mon', emoji: '🌤️', high: 29, low: 21, rain: 10 },
      { day: 'Tue', emoji: '⛅', high: 27, low: 20, rain: 20 },
      { day: 'Wed', emoji: '🌧️', high: 24, low: 18, rain: 75 },
      { day: 'Thu', emoji: '🌧️', high: 22, low: 17, rain: 80 },
      { day: 'Fri', emoji: '⛅', high: 26, low: 19, rain: 25 },
      { day: 'Sat', emoji: '🌤️', high: 28, low: 20, rain: 10 },
      { day: 'Sun', emoji: '☀️', high: 31, low: 22, rain: 5 },
    ],
    hourly: [
      { time: '6 AM', temp: 23, emoji: '🌅' },
      { time: '9 AM', temp: 26, emoji: '⛅' },
      { time: '12 PM', temp: 29, emoji: '🌤️' },
      { time: '3 PM',  temp: 31, emoji: '☀️' },
      { time: '6 PM',  temp: 28, emoji: '🌤️' },
      { time: '9 PM',  temp: 24, emoji: '🌙' },
    ],
    farmingAdvisories: [
      { icon: '✅', text: 'Good conditions for spraying pesticides today — low wind & no rain expected.' },
      { icon: '⚠️', text: 'Rain expected Wed–Thu. Postpone fertiliser application until after rain clears.' },
      { icon: '💧', text: 'High humidity on rainy days may increase fungal disease risk. Monitor closely.' },
      { icon: '☀️', text: 'Intense sun today — consider mulching to retain soil moisture in exposed fields.' },
    ],
    source: 'mock',
    lastUpdated: new Date().toISOString(),
  };
}

// GET /api/weather
router.get('/', async (req, res) => {
  const apiKey = process.env.OPENWEATHER_API_KEY;
  const lat = process.env.FARM_LAT || '20.0059';
  const lon = process.env.FARM_LON || '73.7898';

  if (!apiKey || apiKey === 'your_openweather_api_key_here') {
    // Return mock data
    return res.json({ success: true, data: getMockWeather() });
  }

  try {
    const [current, forecast] = await Promise.all([
      fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`).then(r => r.json()),
      fetch(`https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric&cnt=40`).then(r => r.json()),
    ]);

    const emojiMap = { '01d':'☀️','01n':'🌙','02d':'⛅','02n':'⛅','03d':'☁️','03n':'☁️','04d':'☁️','04n':'☁️','09d':'🌧️','09n':'🌧️','10d':'🌦️','10n':'🌦️','11d':'⛈️','11n':'⛈️','13d':'❄️','13n':'❄️','50d':'🌫️','50n':'🌫️' };

    // Group 5-day forecast by day
    const days = {};
    for (const item of forecast.list) {
      const date = item.dt_txt.split(' ')[0];
      if (!days[date]) days[date] = [];
      days[date].push(item);
    }
    const forecastDays = Object.entries(days).slice(0, 7).map(([date, items]) => {
      const icon = items[4]?.weather[0]?.icon || items[0]?.weather[0]?.icon;
      return {
        day: new Date(date).toLocaleDateString('en-IN', { weekday: 'short' }),
        emoji: emojiMap[icon] || '🌤️',
        high: Math.round(Math.max(...items.map(i => i.main.temp_max))),
        low: Math.round(Math.min(...items.map(i => i.main.temp_min))),
        rain: Math.round((items.filter(i => i.weather[0].main === 'Rain').length / items.length) * 100),
      };
    });

    const icon = current.weather[0].icon;
    res.json({
      success: true,
      data: {
        city: current.name,
        country: current.sys.country,
        temp: Math.round(current.main.temp),
        feelsLike: Math.round(current.main.feels_like),
        humidity: current.main.humidity,
        windSpeed: Math.round(current.wind.speed * 3.6),
        pressure: current.main.pressure,
        description: current.weather[0].description.replace(/\b\w/g, l => l.toUpperCase()),
        icon: emojiMap[icon] || '🌤️',
        forecast: forecastDays,
        farmingAdvisories: getMockWeather().farmingAdvisories,
        source: 'openweathermap',
        lastUpdated: new Date().toISOString(),
      }
    });
  } catch (err) {
    console.error('Weather fetch failed, using mock:', err.message);
    res.json({ success: true, data: getMockWeather() });
  }
});

module.exports = router;
