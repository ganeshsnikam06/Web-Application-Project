// routes/crops.js
const express = require('express');
const router = express.Router();
const store = require('../data/store');

// GET /api/crops — list all crops
router.get('/', (req, res) => {
  const { health, field } = req.query;
  let result = [...store.crops];
  if (health) result = result.filter(c => c.health.toLowerCase().includes(health.toLowerCase()));
  if (field)  result = result.filter(c => c.field.toLowerCase().includes(field.toLowerCase()));
  res.json({ success: true, count: result.length, data: result });
});

// GET /api/crops/summary — dashboard summary
router.get('/summary', (req, res) => {
  const crops = store.crops;
  const healthy   = crops.filter(c => c.health === 'Healthy' || c.health === 'Excellent').length;
  const alerts    = crops.filter(c => c.health === 'Pest Alert' || c.health === 'Needs Water').length;
  const totalAcres = crops.reduce((sum, c) => sum + c.acres, 0);
  const avgStage  = Math.round(crops.reduce((sum, c) => sum + c.stage, 0) / crops.length);
  res.json({ success: true, data: { total: crops.length, healthy, alerts, totalAcres, avgStage } });
});

// GET /api/crops/:id
router.get('/:id', (req, res) => {
  const crop = store.crops.find(c => c.id === parseInt(req.params.id));
  if (!crop) return res.status(404).json({ success: false, message: 'Crop not found' });
  res.json({ success: true, data: crop });
});

// POST /api/crops — add a new crop
router.post('/', (req, res) => {
  const { name, emoji, field, acres, sownDate, harvestDate } = req.body;
  if (!name || !field) return res.status(400).json({ success: false, message: 'name and field are required' });
  const crop = {
    id: store.cropIdCounter++,
    name, emoji: emoji || '🌱', field,
    acres: parseFloat(acres) || 1,
    stage: 0, health: 'Healthy',
    sownDate: sownDate || new Date().toISOString().split('T')[0],
    harvestDate: harvestDate || '',
    daysToHarvest: harvestDate ? Math.ceil((new Date(harvestDate) - new Date()) / 86400000) : null,
    irrigated: false, notes: ''
  };
  store.crops.push(crop);
  res.status(201).json({ success: true, data: crop });
});

// PUT /api/crops/:id — update crop
router.put('/:id', (req, res) => {
  const idx = store.crops.findIndex(c => c.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ success: false, message: 'Crop not found' });
  store.crops[idx] = { ...store.crops[idx], ...req.body, id: store.crops[idx].id };
  res.json({ success: true, data: store.crops[idx] });
});

// DELETE /api/crops/:id
router.delete('/:id', (req, res) => {
  const idx = store.crops.findIndex(c => c.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ success: false, message: 'Crop not found' });
  const removed = store.crops.splice(idx, 1)[0];
  res.json({ success: true, data: removed });
});

module.exports = router;
