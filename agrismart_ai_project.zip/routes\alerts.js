// routes/alerts.js
const express = require('express');
const router = express.Router();
const store = require('../data/store');

// GET /api/alerts
router.get('/', (req, res) => {
  const { read } = req.query;
  let data = [...store.alerts];
  if (read === 'false') data = data.filter(a => !a.read);
  if (read === 'true')  data = data.filter(a => a.read);
  res.json({ success: true, count: data.length, unread: data.filter(a => !a.read).length, data });
});

// PUT /api/alerts/:id/read
router.put('/:id/read', (req, res) => {
  const alert = store.alerts.find(a => a.id === parseInt(req.params.id));
  if (!alert) return res.status(404).json({ success: false, message: 'Alert not found' });
  alert.read = true;
  res.json({ success: true, data: alert });
});

// DELETE /api/alerts/:id
router.delete('/:id', (req, res) => {
  const idx = store.alerts.findIndex(a => a.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ success: false, message: 'Alert not found' });
  store.alerts.splice(idx, 1);
  res.json({ success: true, message: 'Alert dismissed' });
});

module.exports = router;
