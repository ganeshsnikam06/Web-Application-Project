// routes/ai.js
const express = require('express');
const router = express.Router();
const multer = require('multer');
const fetch = require('node-fetch');

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10 MB
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith('image/')) return cb(new Error('Only image files are allowed'));
    cb(null, true);
  }
});

// Google Gemini API Configuration
const GEMINI_MODEL = 'gemini-1.5-flash-latest';
const GEMINI_BASE_URL = `https://generativelanguage.googleapis.com/v1/models/${GEMINI_MODEL}:generateContent?key=`;

const SYSTEM_PROMPT = `You are AgriSmart AI, an expert agricultural advisor for Indian farming.
Help farmers with crops, soil, pests, weather, and market prices.
Respond concisely in 3-6 sentences. Warm and supportive tone.`;

/**
 * Helper to map history roles to Gemini roles
 */
function mapHistoryToGemini(history) {
  return history.map(item => ({
    role: item.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: item.content }]
  }));
}

// POST /api/ai/chat — conversational AI advisor
router.post('/chat', async (req, res) => {
  const { message, history = [], language = 'English' } = req.body;
  
  if (!message || !message.trim()) {
    return res.status(400).json({ success: false, message: 'message is required' });
  }
  
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ success: false, message: 'GEMINI_API_KEY not configured' });
  }

  const langInstruction = language && language !== 'English' ? ` Respond ONLY in ${language}.` : '';
  const fullSystemPrompt = SYSTEM_PROMPT + langInstruction;

  // Use a highly compatible structure by including the system prompt in the contents
  const geminiHistory = mapHistoryToGemini(history.slice(-20));
  const contents = [
    { role: 'user', parts: [{ text: `INSTRUCTIONS: ${fullSystemPrompt}\n\nPlease help the farmer based on these instructions.` }] },
    { role: 'model', parts: [{ text: 'Understood. I will help the farmer as AgriSmart AI in the requested language.' }] },
    ...geminiHistory,
    { role: 'user', parts: [{ text: message.trim() }] }
  ];

  try {
    const response = await fetch(GEMINI_BASE_URL + apiKey, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents }),
    });

    if (!response.ok) {
      const errBody = await response.json();
      console.error('Gemini Error:', JSON.stringify(errBody));
      return res.status(response.status).json({ success: false, message: errBody.error?.message || 'AI service error' });
    }

    const data = await response.json();
    const reply = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    
    res.json({ success: true, data: { reply } });
  } catch (err) {
    console.error('Chat error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to reach AI service' });
  }
});

// POST /api/ai/disease — image-based disease detection
router.post('/disease', upload.single('image'), async (req, res) => {
  if (!req.file) return res.status(400).json({ success: false, message: 'Image file is required' });
  
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ success: false, message: 'GEMINI_API_KEY not configured' });
  }

  const base64 = req.file.buffer.toString('base64');
  const mediaType = req.file.mimetype;

  const prompt = `You are an expert agricultural plant pathologist and botanist. Analyze this crop photo carefully.
Identify any disease, pest damage, nutrient deficiency, or confirm the plant is healthy.
Respond ONLY with a valid JSON object (no markdown, no backticks, no extra text):
{
  "disease": "Disease/condition name",
  "crop": "Crop type if identifiable",
  "severity": "Healthy|Low|Moderate|High|Critical",
  "confidence": 85,
  "description": "2-3 sentence description of what you see and the diagnosis",
  "treatments": ["Specific treatment 1", "Specific treatment 2", "Specific treatment 3"],
  "prevention": "One sentence on prevention for future",
  "urgency": "Monitor|This week|Immediate action needed"
}`;

  try {
    const response = await fetch(GEMINI_BASE_URL + apiKey, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          role: 'user',
          parts: [
            { inline_data: { mime_type: mediaType, data: base64 } },
            { text: prompt }
          ]
        }]
      }),
    });

    if (!response.ok) {
      const err = await response.json();
      return res.status(response.status).json({ success: false, message: err.error?.message || 'Gemini API error' });
    }

    const data = await response.json();
    const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
    
    let parsed;
    try {
      // Clean up any potential markdown formatting
      const cleanJson = rawText.replace(/```json|```/g, '').trim();
      parsed = JSON.parse(cleanJson);
    } catch {
      return res.status(500).json({ success: false, message: 'Failed to parse AI response', raw: rawText });
    }

    res.json({ success: true, data: parsed });
  } catch (err) {
    console.error('Disease detection error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to reach AI service' });
  }
});

// POST /api/ai/recommend — get AI crop recommendations
router.post('/recommend', async (req, res) => {
  const { soilPh, season, location, waterAvailability, targetCrops } = req.body;
  
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ success: false, message: 'GEMINI_API_KEY not configured' });
  }

  const prompt = `A farmer in ${location || 'Nashik, Maharashtra'} wants crop recommendations.
Season: ${season || 'Rabi'}
Soil pH: ${soilPh || 6.8}
Water availability: ${waterAvailability || 'Medium'}
${targetCrops ? `Interested in: ${targetCrops}` : ''}

Provide top 3 crop recommendations as JSON only (no markdown, no backticks, just raw json):
{"recommendations": [{"crop":"Name","emoji":"🌾","suitability":90,"reason":"Why it fits","duration":"Days","estimatedReturn":"₹/acre","tips":["tip1","tip2"]}]}`;

  try {
    const response = await fetch(GEMINI_BASE_URL + apiKey, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: prompt }] }]
      }),
    });

    if (!response.ok) {
      const err = await response.json();
      return res.status(response.status).json({ success: false, message: err.error?.message || 'Gemini API error' });
    }

    const data = await response.json();
    const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
    
    const cleanJson = rawText.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(cleanJson);
    res.json({ success: true, data: parsed });
  } catch (err) {
    console.error('Recommendation error:', err.message);
    res.status(500).json({ success: false, message: 'AI service error' });
  }
});

module.exports = router;
